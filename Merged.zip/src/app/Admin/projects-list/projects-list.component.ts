import { Component, OnInit } from '@angular/core';
import { ProjectDetails } from '../models/project-details';
import { ProjectService } from '../services/project.service';
@Component({
  selector: 'app-projects-list',
  templateUrl: './projects-list.component.html',
  styleUrls: ['./projects-list.component.css']
})
export class ProjectsListComponent implements OnInit {

  projects:ProjectDetails[];
  constructor(private projserv:ProjectService) 
  { 
    
  }

  ngOnInit() {
    this.projects = this.projserv.getAll();
  }
  
  delete(name:string){
    if(confirm(`Are you sure of deleting Project#${name}`)){
      this.projserv.delete(name);
    }
  }
}
