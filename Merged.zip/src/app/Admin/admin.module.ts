import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms'
import { AdminRoutingModule } from './admin-routing.module';

import { AdminHomeComponent } from './admin-home/admin-home.component';
import { InitiateOnboardingComponent } from './Initiate-Onboarding/initiate-onboarding/initiate-onboarding.component';
import { ProjectsListComponent } from './projects-list/projects-list.component';
import { ProjectdetailComponent } from './projectdetail/projectdetail.component';

@NgModule({
  declarations: [
	
	AdminHomeComponent,
	InitiateOnboardingComponent,
    ProjectsListComponent,
    ProjectdetailComponent,
	
  ],
  imports: [
    BrowserModule,
	FormsModule,
    AdminRoutingModule,
	
  ],
  providers: [],
  bootstrap: [InitiateOnboardingComponent]
})
export class AdminModule { }
