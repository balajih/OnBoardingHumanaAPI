import { ProjectDetails } from './project-details';

describe('ProjectDetails', () => {
  it('should create an instance', () => {
    expect(new ProjectDetails()).toBeTruthy();
  });
});
