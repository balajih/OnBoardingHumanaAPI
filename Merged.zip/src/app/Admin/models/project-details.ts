export class ProjectDetails {
        public ProjectName:string;
        public Poc1:string;
        public Poc2:string;       
}
