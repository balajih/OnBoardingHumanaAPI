import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms'
import { AppRoutingModule } from './app-routing.module';
import { AdminModule } from './admin/admin.module';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';

import {MatButtonModule, MatCheckboxModule, MatCardModule} from '@angular/material';


import {NgbCarouselConfig} from '@ng-bootstrap/ng-bootstrap';

import { LoginComponent } from './login.component';
import { HomeComponent } from './home.component';
import { AppComponent } from './app.component';



@NgModule({
  declarations: [
	AppComponent,
    LoginComponent,
	HomeComponent,
	
	
  ],
  imports: [
  MatCardModule, 
  
    BrowserModule,
	FormsModule,
    AppRoutingModule,
	AdminModule,
	NgbModule,
	BrowserAnimationsModule
  ],
  providers: [NgbCarouselConfig],
  bootstrap: [AppComponent]
})
export class AppModule { }
