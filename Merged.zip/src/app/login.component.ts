import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent {
  title = 'HumanaOnboard';
  username: string = '';
  constructor(private router: Router){
  }
  login(){
	  if(this.username == 'admin'){
		  this.router.navigate(['/', 'Admin']);
	  }
	  else{
	    this.router.navigate(['/', 'home']);
	  }

  }
}
